package com.mycompany.mvc;  
public class MVC {  
    public static void main(String[] args) {  
        Inventario modelo = new Inventario();  
        VistaConsola vista = new VistaConsola();  
        Controlador1 controlador = new Controlador1(modelo, vista);  
        controlador.ejecutar();  
    }  
}

