package com.mycompany.mvc;

import java.util.Scanner;
class VistaConsola {
    private final Scanner scanner = new Scanner(System.in);

    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }
    
    public String solicitarTexto(String mensaje) {
        System.out.print(mensaje);
        return scanner.nextLine();
    }
    
    public double solicitarDouble(String mensaje) {
        System.out.print(mensaje);
        return scanner.nextDouble();
    }
    
    public int solicitarInt(String mensaje) {
        System.out.print(mensaje);
        return scanner.nextInt();
    }
}
