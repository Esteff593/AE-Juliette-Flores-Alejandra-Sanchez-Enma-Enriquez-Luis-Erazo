package com.mycompany.mvc;

class Controlador1 {
    private final Inventario modelo;
    private final VistaConsola vista;
    
    public Controlador1(Inventario modelo, VistaConsola vista) {
        this.modelo = modelo;
        this.vista = vista;
    }
    
    public void ejecutar() {
        boolean salir = false;
        while (!salir) {
            vista.mostrarMensaje("1. Registrar Producto\n2. Actualizar Inventario\n3. Consultar Productos\n4. Calcular Valor Total\n5. Salir");
            int opcion = vista.solicitarInt("Seleccione una opción: ");
            vista.solicitarTexto(""); // Captura el salto de línea
            
            switch (opcion) {
                case 1 -> {
                    String nombre = vista.solicitarTexto("Nombre del producto: ");
                    double precio = vista.solicitarDouble("Precio: ");
                    int cantidad = vista.solicitarInt("Cantidad: ");
                    modelo.registrarProducto(nombre, precio, cantidad);
                    vista.mostrarMensaje("Producto registrado correctamente.");
                }
                case 2 -> {
                    String nombre = vista.solicitarTexto("Nombre del producto a actualizar: ");
                    int cantidad = vista.solicitarInt("Nueva cantidad: ");
                    modelo.actualizarInventario(nombre, cantidad);
                    vista.mostrarMensaje("Inventario actualizado.");
                }
                case 3 -> {
                    vista.mostrarMensaje("Lista de productos:");
                    for (Producto p : modelo.consultarProductos()) {
                        vista.mostrarMensaje(p.getNombre() + " - Precio: " + p.getPrecio() + " - Cantidad: " + p.getCantidad());
                    }
                }
                case 4 -> vista.mostrarMensaje("Valor total del inventario: " + modelo.calcularValorTotal());
                case 5 -> salir = true;
                default -> vista.mostrarMensaje("Opción no válida.");
            }
        }
    }
}

    
