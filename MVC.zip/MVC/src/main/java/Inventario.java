package com.mycompany.mvc;

import java.util.ArrayList;
import java.util.List;

public class Inventario {
    private final List<Producto> productos = new ArrayList<>();

    public List<Producto> consultarProductos() {
        return productos;
         }

    public double calcularValorTotal() {
        double total = 0;
        for (Producto p : productos) {
            total += Double.parseDouble(p.getPrecio()) * Integer.parseInt(p.getCantidad());

        }
        return total;
    }

    void registrarProducto(String nombre, double precio, int cantidad) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void actualizarInventario(String nombre, int cantidad) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}





